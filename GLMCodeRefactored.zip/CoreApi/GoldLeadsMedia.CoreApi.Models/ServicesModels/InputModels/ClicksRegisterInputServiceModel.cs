﻿namespace GoldLeadsMedia.CoreApi.Models.ServiceModels
{
    public class ClicksRegisterInputServiceModel
    {
        public string IpAddress { get; set; }
        public string OfferId { get; set; }
        public string LandingPageId { get; set; }
        public string AffiliateId { get; set; }
    }
}
