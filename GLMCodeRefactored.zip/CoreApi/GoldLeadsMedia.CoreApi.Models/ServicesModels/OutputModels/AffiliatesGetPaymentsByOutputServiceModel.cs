﻿namespace GoldLeadsMedia.CoreApi.Models.ServicesModels.OutputModels
{
    public class AffiliatesGetPaymentsByOutputServiceModel
    {
        public decimal Available { get; set; }
        public decimal Paid { get; set; }
    }
}
