﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class ManagersConfirmedLeadsPartner
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
