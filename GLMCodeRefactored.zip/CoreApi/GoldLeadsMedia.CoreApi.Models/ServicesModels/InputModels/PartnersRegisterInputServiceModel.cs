﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldLeadsMedia.CoreApi.Models.ServiceModels
{
    public class PartnersRegisterInputServiceModel
    {
        public string Name { get; set; }
    }
}
