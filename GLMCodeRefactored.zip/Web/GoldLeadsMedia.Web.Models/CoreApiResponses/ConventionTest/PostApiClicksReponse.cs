﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses.ConventionTest
{
    public class PostApiClicksReponse
    {
        public string Id { get; set; }
        public string LandingPageUrl { get; set; }
    }
}
