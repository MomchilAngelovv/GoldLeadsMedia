﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses
{
    public class DeviceApiResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
