﻿namespace GoldLeadsMedia.Web.Models.InputModels
{
    using System.Collections.Generic;

    public class ManagersConfirmLeadsInputModel
    {
        public IEnumerable<string> LeadIds { get; set; }
    }
}
