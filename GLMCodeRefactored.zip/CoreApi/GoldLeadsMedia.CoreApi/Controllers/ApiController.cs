﻿namespace GoldLeadsMedia.CoreApi.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    [ApiController]
    [Route("/Api/[controller]")]
    public class ApiController : ControllerBase
    {

    }
}
