﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    using System.Collections.Generic;

    public class ManagersAffiliateDetailsPaymentsReport
    {
        public IEnumerable<ManagersAffiliateDetailsPayment> Payments { get; set; }
    }
}
