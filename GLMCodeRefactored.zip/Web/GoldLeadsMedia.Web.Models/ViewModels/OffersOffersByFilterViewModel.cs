﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    using System.Collections.Generic;

    public class OffersOffersByFilterViewModel
    {
        public IEnumerable<OffersOffersByFilterOffer> Offers { get; set; }
    }
}
