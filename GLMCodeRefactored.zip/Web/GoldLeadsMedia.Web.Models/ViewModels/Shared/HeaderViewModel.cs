﻿namespace GoldLeadsMedia.Web.Models.ViewModels.Shared
{
    public class HeaderViewModel
    {
        public string ManagerId { get; set; }
        public string ManagerUserName { get; set; }
    }
}
