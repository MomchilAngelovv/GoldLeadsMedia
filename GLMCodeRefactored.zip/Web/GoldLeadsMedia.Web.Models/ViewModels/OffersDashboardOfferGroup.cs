﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class OffersDashboardOfferGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsFirst { get; set; }
    }
}
