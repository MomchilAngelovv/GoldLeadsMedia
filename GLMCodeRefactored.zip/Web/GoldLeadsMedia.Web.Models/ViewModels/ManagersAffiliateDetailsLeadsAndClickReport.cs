﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    using System.Collections.Generic;

    public class ManagersAffiliateDetailsLeadsAndClickReport
    {
        public IEnumerable<ManagersAffiliateDetailsOffer> Offers { get; set; }
    }
}
