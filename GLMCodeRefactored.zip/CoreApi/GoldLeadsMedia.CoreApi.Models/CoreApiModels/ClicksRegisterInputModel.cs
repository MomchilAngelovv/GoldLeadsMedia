﻿namespace GoldLeadsMedia.CoreApi.Models.InputModels
{
    public class ClicksRegisterInputModel
    {
        public string OfferId { get; set; }
        public string LandingPageId { get; set; }
        public string AffiliateId { get; set; }
    }
}
