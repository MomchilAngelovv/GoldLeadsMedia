﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class ManagersNotConfirmedLeadsViewModel
    {
        public IEnumerable<ManagersNotConfirmedLeadsLead> NotConfirmedLeads { get; set; }
    }
}
