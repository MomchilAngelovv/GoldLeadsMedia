﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses
{
    public class LandingPageApiResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
