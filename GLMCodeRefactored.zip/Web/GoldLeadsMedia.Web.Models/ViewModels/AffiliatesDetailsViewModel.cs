﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class AffiliatesDetailsViewModel
    {
        public AffiliatesDetailsAffiliate Affiliate { get; set; }
        public ManagersAffiliateDetailsLeadsAndClickReport LeadsAndClickReport { get; set; }
        public ManagersAffiliateDetailsPaymentsReport PaymentsReport { get; set; }
    }
}
