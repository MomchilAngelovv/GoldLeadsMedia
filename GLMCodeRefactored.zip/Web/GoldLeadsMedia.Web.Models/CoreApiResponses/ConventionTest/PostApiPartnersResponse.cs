﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses.ConventionTest
{
    public class PostApiPartnersResponse
    {
        public string Name { get; set; }
    }
}
