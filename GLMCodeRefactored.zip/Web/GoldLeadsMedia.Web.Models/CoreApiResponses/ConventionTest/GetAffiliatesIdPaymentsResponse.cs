﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses.ConventionTest
{
    public class GetAffiliatesIdPaymentsResponse
    {
        public decimal Available { get; set; }
        public decimal Paid { get; set; }
    }
}
