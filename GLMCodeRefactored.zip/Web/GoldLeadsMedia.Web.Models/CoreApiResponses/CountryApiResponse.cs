﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses
{
    public class CountryApiResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
