﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class ManagersAffiliatesAffiliate
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string Skype { get; set; }
        public string Experience { get; set; }
        public bool IsVip { get; set; }
        public bool IsDeleted { get; set; }
    }
}
