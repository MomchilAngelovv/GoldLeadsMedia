﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldLeadsMedia.CoreApi.Models.InputModels
{
    public class PartnersRegisterInputModel
    {
        public string Name { get; set; }
    }
}
