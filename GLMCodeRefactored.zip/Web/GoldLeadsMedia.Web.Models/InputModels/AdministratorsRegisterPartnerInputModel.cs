﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoldLeadsMedia.Web.Models.InputModels
{
    public class AdministratorsRegisterPartnerInputModel
    {
        public string Name { get; set; }
    }
}
