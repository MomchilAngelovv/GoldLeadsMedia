﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    using System.Collections.Generic;

    public class ManagersAffiliatesViewModel
    {
        public IEnumerable<ManagersAffiliatesAffiliate> Affiliates { get; set; }
    }
}
