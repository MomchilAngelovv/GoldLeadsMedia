﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class OffersOfferViewModel
    {
        public string Id { get; set; }
        public string ImageUrl { get; set; }
        public string Name { get; set; }
        public string PayOut { get; set; }
        public string PaymentType { get; set; }
    }
}
