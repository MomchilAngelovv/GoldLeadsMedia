﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    public class OffersDetailsLandingPage
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
