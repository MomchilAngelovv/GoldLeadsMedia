﻿namespace GoldLeadsMedia.Web.Models.ViewModels
{
    using System.Collections.Generic;

    public class OffersOffersByGroupViewModel
    {
        public IEnumerable<OffersOfferViewModel> Offers { get; set; }
    }
}
