﻿namespace GoldLeadsMedia.Web.Models.CoreApiResponses
{
    public class OfferApiResponse
    {
        public string Id { get; set; }
        public string Number { get; set; }
        public string Name { get; set; }
    }
}
