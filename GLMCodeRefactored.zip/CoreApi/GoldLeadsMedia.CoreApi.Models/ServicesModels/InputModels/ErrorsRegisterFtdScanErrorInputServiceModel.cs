﻿namespace GoldLeadsMedia.CoreApi.Models.ServicesModels.InputModels
{
    public class ErrorsRegisterFtdScanErrorInputServiceModel
    {
        public string Message { get; set; }
        public string Information { get; set; }
        public string PartnerName { get; set; }
    }
}
